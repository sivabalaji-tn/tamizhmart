<?php
// -----------------------------------------------------------------
//  Google OAuth 2.0 Credentials
//  ??  NEVER commit this file with real secrets to a public repo.
//      Add config/google_oauth_config.php to your .gitignore
// -----------------------------------------------------------------

define('GOOGLE_CLIENT_ID',
    '947382648814-v7lg98niqbcithjp7h5uhl1qlk1drmpn.apps.googleusercontent.com');

define('GOOGLE_CLIENT_SECRET',
    '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');

// ── Redirect URI (auto-detects local vs production) ─────────────
$_host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$_is_local = in_array($_host, ['localhost', 'localhost:8080', '127.0.0.1', '127.0.0.1:8080'], true)
             || (substr($_host, -6) === '.local');

define('GOOGLE_REDIRECT_URI',
    $_is_local
        ? 'http://localhost:8080/auth/google_callback.php'   // local dev
        : 'https://tamizhmart.optikl.ink/auth/google_callback.php' // production
);
unset($_host, $_is_local);

// When going live, change to your real domain, e.g.:
// define('GOOGLE_REDIRECT_URI', 'https://yourdomain.com/auth/google_callback.php');

// -- OAuth Endpoint URLs (do not change) -------------------------
define('GOOGLE_AUTH_URL',  'https://accounts.google.com/o/oauth2/v2/auth');
define('GOOGLE_TOKEN_URL', 'https://oauth2.googleapis.com/token');
define('GOOGLE_CERTS_URL', 'https://www.googleapis.com/oauth2/v3/certs');
